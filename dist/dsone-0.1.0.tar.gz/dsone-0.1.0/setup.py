# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['poetry']

package_data = \
{'': ['*']}

modules = \
['dsone']
entry_points = \
{'console_scripts': ['lads = dsone:cli']}

setup_kwargs = {
    'name': 'dsone',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'jonzhaopeng',
    'author_email': 'mobiwof@163.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'py_modules': modules,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
